import tkinter as tk
from tkinter import filedialog, messagebox
from encryption import encrypt_image, save_encrypted_image
from decryption import decrypt_image, save_decrypted_image
from PIL import Image

class ImageEncryptionApp:
    def __init__(self, master):
        self.master = master
        master.title("Image Encryption App")

        self.label = tk.Label(master, text="Image Encryption and Decryption")
        self.label.pack()

        self.encrypt_button = tk.Button(master, text="Encrypt Image", command=self.encrypt_image)
        self.encrypt_button.pack()

        self.decrypt_button = tk.Button(master, text="Decrypt Image", command=self.decrypt_image)
        self.decrypt_button.pack()

    def encrypt_image(self):
        image_path = filedialog.askopenfilename()
        password = self.ask_password()
        encrypted_bytes, salt = encrypt_image(image_path, password)
        output_path = filedialog.asksaveasfilename(defaultextension=".enc")
        save_encrypted_image(encrypted_bytes, salt, output_path)
        messagebox.showinfo("Success", "Image encrypted successfully!")

    def decrypt_image(self):
        encrypted_path = filedialog.askopenfilename()
        password = self.ask_password()
        decrypted_bytes = decrypt_image(encrypted_path, password)
        output_path = filedialog.asksaveasfilename(defaultextension=".png")
        img = Image.open(encrypted_path)
        save_decrypted_image(decrypted_bytes, output_path, img.size, img.mode)
        messagebox.showinfo("Success", "Image decrypted successfully!")

    def ask_password(self):
        password = tk.simpledialog.askstring("Password", "Enter encryption/decryption password:", show='*')
        return password
