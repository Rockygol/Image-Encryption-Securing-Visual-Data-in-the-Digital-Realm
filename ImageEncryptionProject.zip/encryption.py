from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from PIL import Image
import os

def generate_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

def encrypt_image(image_path, password):
    img = Image.open(image_path)
    img_bytes = img.tobytes()
    salt = os.urandom(16)
    key = generate_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CFB(salt), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_bytes = encryptor.update(img_bytes) + encryptor.finalize()
    return encrypted_bytes, salt

def save_encrypted_image(encrypted_bytes, salt, output_path):
    with open(output_path, 'wb') as f:
        f.write(salt + encrypted_bytes)
