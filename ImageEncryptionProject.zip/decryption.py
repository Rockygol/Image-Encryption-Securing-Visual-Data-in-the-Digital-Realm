from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from PIL import Image

def decrypt_image(encrypted_path, password):
    with open(encrypted_path, 'rb') as f:
        data = f.read()
    salt = data[:16]
    encrypted_bytes = data[16:]
    key = generate_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CFB(salt), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_bytes = decryptor.update(encrypted_bytes) + decryptor.finalize()
    return decrypted_bytes

def save_decrypted_image(decrypted_bytes, output_path, image_size, image_mode):
    img = Image.frombytes(image_mode, image_size, decrypted_bytes)
    img.save(output_path)
