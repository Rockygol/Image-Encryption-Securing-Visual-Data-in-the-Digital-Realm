import os

def save_key(key, file_path):
    with open(file_path, 'wb') as f:
        f.write(key)

def load_key(file_path):
    with open(file_path, 'rb') as f:
        key = f.read()
    return key
